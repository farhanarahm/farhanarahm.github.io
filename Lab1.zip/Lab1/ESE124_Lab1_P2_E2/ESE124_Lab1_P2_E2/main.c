//
//  main.c
//  ESE124_Lab1_P2_E2
//
//  Created by Farhana Rahman on 1/29/22.

//    2)    Write a C program that displays the following information:
//    H. Smith /78 \ aaa #67 "ggg"
//    mmm


#include <stdio.h>

int main() {
    printf("H. Smith /78 \\ aaa #67 \"ggg\"\nmmm \n");
    return 0;
}

//to add backslash within print: \
//to add quotations: " "
