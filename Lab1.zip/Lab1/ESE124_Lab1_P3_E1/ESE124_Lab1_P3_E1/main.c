//
//  main.c
//  ESE124_Lab1_P3_E1
//
// Created by Farhana Rahman on 1/29/22.
// The operations associated to the characters are as follows:
// e   computes e^x
// /   compute ln x
// r   computes the square root of x
// m computes the absolute value of x


#include <stdio.h>
#include <math.h>

int main()
{
    float x;
   
    char operation;
    int i;
    
    
    for(i=0;i<10;i++){
        
    printf("Enter a number: ");
    scanf("%f",&x);
    getchar();
        
    printf("Enter an operation: ");
    scanf("%c",&operation);
        
    switch(operation){
        case 'e':
            printf("e^%f = %f\n",x,exp(x));
            break;
        case '/':
            if (x <= 0){
                printf("Invalid input \n");
            }
            else
                printf("ln(%f) = %f\n",x,log(x));
            break;
        case 'r':
            if (x < 0){
                printf("Invalid input \n");
            }
            else
            printf("%f^1/2 = %f\n",x,sqrt(x));
            break;
        case 'm':
            printf("|%f| = %f\n",x,fabs(x));
            break;
        default:
            printf("\nInvalid option selected");
        }
    }
    return 0;
    }
  
   
    
    
    
    
    
    
    
    
    

