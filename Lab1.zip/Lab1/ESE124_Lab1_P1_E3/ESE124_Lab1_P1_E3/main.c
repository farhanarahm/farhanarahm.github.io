//
//  main.c
//  ESE124_Lab1_P1_E3
//
//  Created by Farhana Rahman on 1/29/22.
//

#include <stdio.h>

int main()
{
    int month;          //variable for month
    int day;            //variable for day
    int year;           //variable for year
    int month_numbers[12]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    //January, Febuary, March, April, May, June, July, August, September, October, November, December
    int valid=0;        //variable for if the date is valid or not
    int i;

    for(i = 1;i <= 10;i++)                      //for loop, i for index
        {

    printf("Enter a date: ");                  //User enters a date
    scanf("%d/%d/%d",&month,&day,&year);       //Scans for the values of the month, day, and year
        

       //Checking the conditions for the months
    if (month<13)                           //12 months
       {
    if(day <= month_numbers[month-1] )   //if the day is less than or equal to the value listed in days in month index
        valid=1;
       }
        
    if (valid!=1)
        printf("Invalid date!\n");  //if doesn't meet requirements, then it is not a valid date
    else
        printf("Month: %d - Day: %d - Year: %d\n",month,day,year);   //if valid date, it will print
    
        }
}
