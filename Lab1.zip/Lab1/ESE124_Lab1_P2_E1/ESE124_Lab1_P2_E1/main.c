//
//  main.c
//  ESE124_Lab1_P2_E1
//
//  Created by Farhana Rahman on 1/29/22.
//  1) Write a C program that reads a sequence of floating point numbers (decimal numbers)
//     and displays their sum after every number input. Three decimal numbers are displayed for the sum.

#include <stdio.h>

int main() {
    
    float num;
    float sum = 0.0;
    int index;

    for (index=0;index<10;index++){  //for loop format, count starts at 0
    printf("Enter a number: ");
    scanf("%f", &num);

    sum=sum+num; //add the number by the sum

    printf("Here is the sum: %0.3f \n", sum); //three decimal places


}
}
